# Contributing to Playwright Test Automation Framework

Thank you for your interest in contributing to our production-grade Playwright test automation framework! This document provides guidelines and information for contributors.

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Git
- Basic knowledge of TypeScript and Playwright

### Setup Development Environment

1. **Fork and Clone**
   ```bash
   git clone https://github.com/your-username/playwright-framework.git
   cd playwright-framework
   ```

2. **Install Dependencies**
   ```bash
   npm install
   npx playwright install
   ```

3. **Setup Environment**
   ```bash
   cp .env.example .env
   npm run mcp:setup
   ```

4. **Run Tests**
   ```bash
   npm run test
   npm run test:mcp
   ```

## 📋 Contribution Guidelines

### Code Standards

1. **TypeScript Best Practices**
   - Use strict TypeScript configuration
   - Provide comprehensive type definitions
   - Follow naming conventions (camelCase, PascalCase)
   - Add JSDoc comments for public methods

2. **Testing Standards**
   - Write tests for new features
   - Maintain test coverage above 80%
   - Follow Page Object Model patterns
   - Use descriptive test names and tags

3. **Code Quality**
   - Run ESLint before committing: `npm run lint`
   - Follow existing code formatting
   - Use meaningful variable and function names
   - Keep functions focused and small

### Commit Message Format

Use conventional commits format:
```
type(scope): description

[optional body]

[optional footer]
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes
- `refactor`: Code refactoring
- `test`: Test additions/modifications
- `chore`: Maintenance tasks

**Examples:**
```
feat(mcp): add natural language command validation
fix(api): handle timeout errors in API client
docs(readme): update MCP integration guide
test(visual): add mobile viewport regression tests
```

## 🎯 Areas for Contribution

### 1. Core Framework Enhancements
- **Page Objects**: Add new page object implementations
- **Utilities**: Enhance existing utilities or add new ones
- **Error Handling**: Improve error handling and recovery
- **Performance**: Optimize test execution speed

### 2. MCP Integration Improvements
- **Command Templates**: Add new natural language command patterns
- **Validation**: Enhance command validation logic
- **Generators**: Improve test generation capabilities
- **Documentation**: Expand MCP usage examples

### 3. Testing Capabilities
- **Visual Testing**: Enhance screenshot comparison
- **API Testing**: Add new API testing utilities
- **Performance**: Expand performance monitoring
- **Mobile Testing**: Improve mobile testing support

### 4. CI/CD and DevOps
- **GitHub Actions**: Enhance workflow configurations
- **Reporting**: Improve test reporting formats
- **Docker**: Add containerization support
- **Cloud Integration**: Add cloud testing platform support

## 🔧 Development Workflow

### 1. Feature Development

1. **Create Feature Branch**
   ```bash
   git checkout -b feat/your-feature-name
   ```

2. **Implement Changes**
   - Write code following established patterns
   - Add comprehensive tests
   - Update documentation

3. **Test Your Changes**
   ```bash
   npm run test
   npm run test:mcp
   npm run lint
   ```

4. **Commit Changes**
   ```bash
   git add .
   git commit -m "feat(scope): your feature description"
   ```

### 2. Pull Request Process

1. **Push to Your Fork**
   ```bash
   git push origin feat/your-feature-name
   ```

2. **Create Pull Request**
   - Use descriptive title and description
   - Reference related issues
   - Include screenshots for UI changes
   - Add test results if applicable

3. **Code Review Process**
   - Address reviewer feedback
   - Update tests if needed
   - Ensure CI passes

## 📝 Adding New Features

### Adding New Page Objects

```typescript
// src/pages/new-page.ts
import { Page, Locator } from '@playwright/test';
import { BasePage } from './base-page';

export class NewPage extends BasePage {
  private readonly element: Locator;

  constructor(page: Page) {
    super(page);
    this.element = page.locator('[data-testid="element"]');
  }

  protected getUrl(): string {
    return '/new-page';
  }

  public async performAction(): Promise<void> {
    await this.clickElement(this.element);
  }
}
```

### Adding MCP Command Templates

```typescript
// src/mcp/command-templates.ts
export const MCPCommandTemplates = {
  // Add new category
  newCategory: {
    examples: [
      'new command example',
      'another command pattern',
    ],
    patterns: [
      'new "{parameter}" pattern',
    ],
    bestPractices: [
      'Best practice for new commands',
    ],
  },
};
```

### Adding New Tests

```typescript
// src/tests/category/new-test.spec.ts
import { test, expect } from '@playwright/test';
import { NewPage } from '../../pages/new-page';

test.describe('New Feature Tests', () => {
  test('should test new functionality @smoke', async ({ page }) => {
    const newPage = new NewPage(page);
    await newPage.navigate();
    await newPage.performAction();
    // Add assertions
  });
});
```

## 🧪 Testing Guidelines

### Test Categories and Tags

Use appropriate tags for test categorization:
- `@smoke` - Critical functionality tests
- `@regression` - Full regression suite
- `@api` - API endpoint tests
- `@visual` - Visual regression tests
- `@performance` - Performance benchmarks
- `@mcp` - MCP natural language tests
- `@mobile` - Mobile-specific tests

### Writing Effective Tests

1. **Test Structure**
   ```typescript
   test.describe('Feature Group', () => {
     test.beforeEach(async ({ page }) => {
       // Setup
     });

     test('should do something specific @tag', async ({ page }) => {
       // Arrange
       // Act
       // Assert
     });

     test.afterEach(async ({ page }, testInfo) => {
       // Cleanup
     });
   });
   ```

2. **Natural Language Tests**
   ```json
   {
     "name": "Descriptive Test Name",
     "description": "What this test validates",
     "tags": ["category", "priority"],
     "steps": [
       {
         "command": "clear, specific command",
         "description": "What this step does"
       }
     ]
   }
   ```

## 📚 Documentation

### Code Documentation

- Add JSDoc comments for all public methods
- Include parameter descriptions and return types
- Provide usage examples for complex functions
- Document any side effects or prerequisites

### README Updates

When adding new features:
- Update feature list
- Add usage examples
- Update installation/setup instructions
- Include new npm scripts

## 🐛 Bug Reports

### Before Reporting

1. Check existing issues
2. Reproduce the bug consistently
3. Test with latest version
4. Gather relevant information

### Bug Report Template

```markdown
**Bug Description**
Clear description of the bug

**Steps to Reproduce**
1. Step one
2. Step two
3. Step three

**Expected Behavior**
What should happen

**Actual Behavior**
What actually happens

**Environment**
- OS: [e.g., Windows 10, macOS 12]
- Node.js version: [e.g., 18.17.0]
- Browser: [e.g., Chrome 118]
- Framework version: [e.g., 2.0.0]

**Additional Context**
Screenshots, logs, or other relevant information
```

## 🎉 Recognition

Contributors will be recognized in:
- README.md contributors section
- Release notes for significant contributions
- GitHub contributors page

## 📞 Getting Help

- **GitHub Issues**: For bugs and feature requests
- **GitHub Discussions**: For questions and general discussion
- **Code Review**: For implementation guidance

## 📄 License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

Thank you for contributing to making this framework better! 🚀