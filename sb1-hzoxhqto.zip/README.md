# Production-Grade Playwright Test Automation Framework

A comprehensive, enterprise-level test automation framework built with Playwright and TypeScript, featuring **Natural Language Testing via MCP (Model Context Protocol)** integration, following industry best practices and designed for scalability.

## 🚀 Features

### Core Capabilities
- **Page Object Model (POM)** - Clean, maintainable page object implementation
- **TypeScript Support** - Full type safety and IntelliSense
- **Multi-Browser Testing** - Chrome, Firefox, Safari, and mobile browsers
- **API Testing** - Comprehensive REST API testing capabilities
- **Visual Regression Testing** - Screenshot comparison and visual validation
- **Performance Testing** - Load time and resource optimization monitoring
- **Cross-Platform** - Windows, macOS, and Linux support

### 🆕 Natural Language Testing (MCP Integration)
- **Natural Language Commands** - Write tests in plain English
- **JSON Test Definitions** - Define test suites in structured JSON format
- **Auto-Generated Tests** - Convert natural language to Playwright code
- **Command Templates** - Pre-built patterns and best practices
- **Batch Execution** - Run multiple commands in sequence
- **Visual Feedback** - Screenshots and visual validation support

### Advanced Features
- **Centralized Configuration** - Environment-specific configurations
- **Comprehensive Logging** - Winston-based logging with multiple levels
- **Custom Reporters** - Enhanced reporting with screenshots and metrics
- **Test Decorators** - Retry, performance monitoring, and screenshot decorators
- **Data Factories** - Dynamic test data generation
- **Browser Management** - Singleton pattern for efficient resource usage
- **CI/CD Integration** - GitHub Actions workflows included

## 📁 Project Structure

```
src/
├── config/
│   └── test.config.ts          # Environment configurations
├── mcp/                        # 🆕 Natural Language Testing
│   ├── mcp-client.ts          # MCP server communication
│   ├── natural-language-test.ts # Natural language test runner
│   └── command-templates.ts    # Command patterns and guides
├── pages/
│   ├── base-page.ts            # Base page class
│   └── home-page.ts            # Page object examples
├── api/
│   └── api-client.ts           # API testing utilities
├── tests/
│   ├── ui/                     # UI tests
│   ├── api/                    # API tests
│   ├── visual/                 # Visual regression tests
│   ├── performance/            # Performance tests
│   ├── mcp/                    # 🆕 MCP-based tests
│   └── generated/              # 🆕 Auto-generated tests
├── test-data/
│   └── natural-language-tests/ # 🆕 JSON test definitions
├── utils/
│   ├── logger.ts               # Centralized logging
│   ├── browser-manager.ts      # Browser management
│   ├── test-decorators.ts      # Custom decorators
│   ├── test-data-factory.ts    # Test data generation
│   ├── custom-reporter.ts      # Custom reporting
│   └── mcp-test-generator.ts   # 🆕 MCP test utilities
├── types/
│   └── index.ts                # TypeScript interfaces
└── reports/                    # Test reports and artifacts
```

## 🛠️ Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd playwright-framework
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Install Playwright browsers**
   ```bash
   npx playwright install
   ```

4. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

5. **🆕 Setup MCP Integration**
   ```bash
   npm run mcp:setup
   ```

## 🎯 Usage

### Traditional Testing

```bash
# Run all tests
npm run test

# Run tests in headed mode
npm run test:headed

# Run tests with UI mode
npm run test:ui

# Run specific test categories
npm run test:api
npm run test:visual
npm run test:performance

# Run tests in debug mode
npm run test:debug

# Generate and view reports
npm run test:report
```

### 🆕 Natural Language Testing (MCP)

```bash
# Run MCP-based tests
npm run test:mcp

# Generate Playwright tests from JSON definitions
npm run mcp:generate

# Validate natural language test files
npm run mcp:validate

# Get command usage statistics
npm run mcp:stats
```

## 📝 Writing Natural Language Tests

### 1. JSON Test Definition

Create a JSON file in `src/test-data/natural-language-tests/`:

```json
{
  "name": "Login Flow Test",
  "description": "Test user login functionality",
  "tags": ["login", "authentication", "smoke"],
  "setup": [
    {
      "command": "navigate to \"/login\"",
      "description": "Go to login page"
    }
  ],
  "steps": [
    {
      "command": "type \"user@example.com\" into email field",
      "description": "Enter email address"
    },
    {
      "command": "enter \"password123\" in password input",
      "description": "Enter password"
    },
    {
      "command": "click on \"Login\" button",
      "description": "Submit login form"
    },
    {
      "command": "verify page title contains \"Dashboard\"",
      "description": "Confirm successful login",
      "assertions": [
        "check that \"Welcome\" text is visible"
      ]
    }
  ],
  "cleanup": [
    {
      "command": "take screenshot of current page",
      "description": "Capture final state"
    }
  ]
}
```

### 2. Command Templates and Patterns

#### Navigation Commands
```
navigate to "https://example.com"
go to page "/login"
visit the homepage
```

#### Interaction Commands
```
click on "Login" button
type "john@example.com" into email field
select "United States" from country dropdown
check the "I agree" checkbox
```

#### Verification Commands
```
verify page title contains "Dashboard"
check that "Welcome" text is visible
assert element with id "success-message" exists
```

#### Visual Commands
```
take screenshot of current page
scroll to bottom of page
hover over the profile menu
```

### 3. Programmatic Usage

```typescript
import { NaturalLanguageTest } from '../mcp/natural-language-test';

test('natural language test example', async ({ page }) => {
  const nlTest = new NaturalLanguageTest(page, 'My Test');
  
  // Execute single command
  await nlTest.executeCommand('navigate to "/"');
  
  // Execute multiple commands
  await nlTest.executeCommands([
    'click on "Get Started" button',
    'verify page URL contains "/welcome"'
  ]);
  
  // Load from JSON file
  await NaturalLanguageTest.fromJsonFile(page, './test-data/my-test.json');
});
```

## 🎨 Command Templates Guide

### Best Practices for Natural Language Commands

1. **Be Specific and Clear**
   ```
   ✅ click on "Submit" button
   ❌ click submit
   ```

2. **Use Descriptive Element Identifiers**
   ```
   ✅ type "user@example.com" into email field
   ❌ type email
   ```

3. **Include Context When Needed**
   ```
   ✅ select "Premium" from subscription dropdown
   ❌ select premium
   ```

4. **Use Consistent Patterns**
   ```
   ✅ verify page title contains "Expected Title"
   ✅ check that "Success Message" text is visible
   ✅ assert element with id "confirmation" exists
   ```

### Command Categories

- **Navigation**: `navigate`, `go to`, `visit`
- **Clicking**: `click on`, `tap on`
- **Text Input**: `type`, `enter`, `fill`
- **Selection**: `select`, `choose`
- **Verification**: `verify`, `check`, `assert`
- **Waiting**: `wait for`, `pause`
- **Visual**: `screenshot`, `scroll`, `hover`

## 🔧 Configuration

### MCP Server Configuration

Add to your `.env` file:
```
MCP_ENDPOINT=http://localhost:3001
MCP_TIMEOUT=30000
```

### Test Configuration

Edit `src/config/test.config.ts` to customize:
- Base URLs for different environments
- Timeout settings
- Browser preferences
- Logging levels
- Screenshot settings
- Report configurations

## 📊 Reporting

The framework generates multiple report formats:

- **HTML Report** - Interactive visual reports
- **JSON Report** - Machine-readable test results
- **JUnit Report** - CI/CD integration
- **Custom Report** - Enhanced reporting with metrics
- **🆕 MCP Command Statistics** - Natural language command usage analytics

## 🚀 CI/CD Integration

### GitHub Actions

The framework includes comprehensive GitHub Actions workflows with MCP support:

```yaml
- name: Run MCP Tests
  run: npm run test:mcp
  env:
    CI: true
    TEST_ENV: ci
    MCP_ENDPOINT: ${{ secrets.MCP_ENDPOINT }}
```

## 🎭 Advanced MCP Features

### 1. Command Validation
```typescript
import { CommandTemplateHelper } from '../mcp/command-templates';

const validation = CommandTemplateHelper.validateCommand('click on button');
console.log(validation.suggestions); // Get command suggestions
```

### 2. Batch Command Execution
```typescript
const commands = [
  { command: 'navigate to "/"', delay: 1000 },
  { command: 'click on "Menu" button' },
  { command: 'verify "Navigation" is visible' }
];

await nlTest.executeBatch(page, commands, { stopOnError: true });
```

### 3. Auto-Generated Test Files
```bash
# Generate Playwright tests from all JSON files
npm run mcp:generate

# This creates .spec.ts files in src/tests/generated/
```

## 🤝 Contributing

### Adding New Command Templates

1. Edit `src/mcp/command-templates.ts`
2. Add new command patterns and examples
3. Update validation logic
4. Add tests for new commands

### Creating Test Templates

```bash
# Use the generator utility
npm run mcp:setup
```

Or programmatically:
```typescript
import { mcpTestGenerator } from './src/utils/mcp-test-generator';

mcpTestGenerator.createTestTemplate(
  'My New Test',
  'Description of the test',
  ['smoke', 'regression']
);
```

## 📚 Examples

### Complete Test Suite Example

```json
{
  "name": "E-commerce Checkout Flow",
  "description": "Complete checkout process testing",
  "tags": ["e-commerce", "checkout", "critical"],
  "setup": [
    { "command": "navigate to \"/products\"" },
    { "command": "wait for page to load completely" }
  ],
  "steps": [
    {
      "command": "click on first \"Add to Cart\" button",
      "description": "Add product to cart"
    },
    {
      "command": "click on \"Cart\" icon",
      "description": "Open shopping cart"
    },
    {
      "command": "verify \"1 item\" text is visible",
      "description": "Confirm item in cart"
    },
    {
      "command": "click on \"Checkout\" button",
      "description": "Proceed to checkout"
    },
    {
      "command": "fill checkout form with test data",
      "description": "Complete checkout form"
    },
    {
      "command": "click on \"Place Order\" button",
      "description": "Submit order"
    },
    {
      "command": "verify \"Order Confirmed\" message appears",
      "description": "Confirm successful order"
    }
  ],
  "cleanup": [
    { "command": "take screenshot of confirmation page" }
  ]
}
```

## 🆘 Support

- **Documentation** - Check this README and inline comments
- **Issues** - Create GitHub issues for bugs and feature requests
- **Discussions** - Use GitHub discussions for questions
- **MCP Commands** - Use `npm run mcp:validate` to check command syntax

## 🔄 Changelog

### v2.0.0 - MCP Integration
- ✨ Added natural language testing via MCP
- ✨ JSON-based test definitions
- ✨ Auto-generated Playwright tests
- ✨ Command templates and validation
- ✨ Batch command execution
- ✨ Enhanced reporting with command statistics

---

**Happy Testing with Natural Language! 🎭🗣️**

This framework now supports both traditional Playwright testing and innovative natural language testing via MCP integration. Write tests in plain English and let the framework handle the automation complexity!