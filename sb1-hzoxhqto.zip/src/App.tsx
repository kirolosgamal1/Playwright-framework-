import React from 'react';
import { TestTube as TestRunner } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex justify-center mb-8">
            <div className="bg-white p-4 rounded-full shadow-lg">
              <TestRunner className="w-16 h-16 text-blue-600" />
            </div>
          </div>
          
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Playwright Test Framework
          </h1>
          
          <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
            Production-grade end-to-end test automation framework built with Playwright, TypeScript, 
            and enterprise-level best practices for scalable testing solutions.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <h3 className="text-xl font-semibold text-gray-900 mb-3">🎭 Multi-Browser</h3>
              <p className="text-gray-600">
                Test across Chrome, Firefox, Safari, and mobile browsers with parallel execution
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <h3 className="text-xl font-semibold text-gray-900 mb-3">📱 Visual Testing</h3>
              <p className="text-gray-600">
                Automated visual regression testing with screenshot comparison and pixel-perfect validation
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <h3 className="text-xl font-semibold text-gray-900 mb-3">⚡ Performance</h3>
              <p className="text-gray-600">
                Built-in performance monitoring with load time analysis and resource optimization
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <h3 className="text-xl font-semibold text-gray-900 mb-3">🔧 API Testing</h3>
              <p className="text-gray-600">
                Comprehensive REST API testing with request/response validation and error handling
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <h3 className="text-xl font-semibold text-gray-900 mb-3">📊 Reporting</h3>
              <p className="text-gray-600">
                Advanced reporting with HTML, JSON, and custom formats plus CI/CD integration
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <h3 className="text-xl font-semibold text-gray-900 mb-3">🏗️ Architecture</h3>
              <p className="text-gray-600">
                Page Object Model with TypeScript, SOLID principles, and enterprise-grade structure
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Quick Start</h2>
            <div className="bg-gray-900 text-green-400 p-4 rounded-lg text-left overflow-x-auto">
              <pre className="text-sm">
{`# Install dependencies
npm install

# Install Playwright browsers
npx playwright install

# Run all tests
npm run test

# Run tests with UI
npm run test:ui

# Run specific test types
npm run test:api
npm run test:visual
npm run test:performance`}
              </pre>
            </div>
          </div>
          
          <div className="flex justify-center space-x-4">
            <button 
              onClick={() => window.open('/README.md', '_blank')}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors"
            >
              View Documentation
            </button>
            <button 
              onClick={() => window.open('https://playwright.dev/', '_blank')}
              className="bg-gray-800 hover:bg-gray-900 text-white px-8 py-3 rounded-lg font-semibold transition-colors"
            >
              Playwright Docs
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;