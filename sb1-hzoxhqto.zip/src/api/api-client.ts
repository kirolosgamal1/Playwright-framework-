import { APIRequestContext } from '@playwright/test';
import { logger } from '../utils/logger';
import { config } from '../config/test.config';
import { ApiResponse } from '../types';

/**
 * API client for making HTTP requests with comprehensive error handling
 */
export class ApiClient {
  private context: APIRequestContext;
  private baseUrl: string;

  constructor(context: APIRequestContext) {
    this.context = context;
    this.baseUrl = config.apiUrl || '';
  }

  /**
   * Make a GET request
   */
  public async get<T = any>(
    endpoint: string,
    options?: {
      params?: Record<string, string>;
      headers?: Record<string, string>;
      timeout?: number;
    }
  ): Promise<ApiResponse<T>> {
    const startTime = Date.now();
    const url = this.buildUrl(endpoint, options?.params);

    try {
      const response = await this.context.get(url, {
        headers: options?.headers,
        timeout: options?.timeout || config.timeouts.action,
      });

      const duration = Date.now() - startTime;
      const data = await this.parseResponse<T>(response);

      logger.api('GET', url, response.status(), duration);

      return {
        status: response.status(),
        statusText: response.statusText(),
        data,
        headers: response.headers(),
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`GET request failed: ${url}`, { error, duration });
      throw error;
    }
  }

  /**
   * Make a POST request
   */
  public async post<T = any>(
    endpoint: string,
    data?: any,
    options?: {
      headers?: Record<string, string>;
      timeout?: number;
    }
  ): Promise<ApiResponse<T>> {
    const startTime = Date.now();
    const url = this.buildUrl(endpoint);

    try {
      const response = await this.context.post(url, {
        data,
        headers: {
          'Content-Type': 'application/json',
          ...options?.headers,
        },
        timeout: options?.timeout || config.timeouts.action,
      });

      const duration = Date.now() - startTime;
      const responseData = await this.parseResponse<T>(response);

      logger.api('POST', url, response.status(), duration);

      return {
        status: response.status(),
        statusText: response.statusText(),
        data: responseData,
        headers: response.headers(),
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`POST request failed: ${url}`, { error, duration });
      throw error;
    }
  }

  /**
   * Make a PUT request
   */
  public async put<T = any>(
    endpoint: string,
    data?: any,
    options?: {
      headers?: Record<string, string>;
      timeout?: number;
    }
  ): Promise<ApiResponse<T>> {
    const startTime = Date.now();
    const url = this.buildUrl(endpoint);

    try {
      const response = await this.context.put(url, {
        data,
        headers: {
          'Content-Type': 'application/json',
          ...options?.headers,
        },
        timeout: options?.timeout || config.timeouts.action,
      });

      const duration = Date.now() - startTime;
      const responseData = await this.parseResponse<T>(response);

      logger.api('PUT', url, response.status(), duration);

      return {
        status: response.status(),
        statusText: response.statusText(),
        data: responseData,
        headers: response.headers(),
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`PUT request failed: ${url}`, { error, duration });
      throw error;
    }
  }

  /**
   * Make a DELETE request
   */
  public async delete<T = any>(
    endpoint: string,
    options?: {
      headers?: Record<string, string>;
      timeout?: number;
    }
  ): Promise<ApiResponse<T>> {
    const startTime = Date.now();
    const url = this.buildUrl(endpoint);

    try {
      const response = await this.context.delete(url, {
        headers: options?.headers,
        timeout: options?.timeout || config.timeouts.action,
      });

      const duration = Date.now() - startTime;
      const responseData = await this.parseResponse<T>(response);

      logger.api('DELETE', url, response.status(), duration);

      return {
        status: response.status(),
        statusText: response.statusText(),
        data: responseData,
        headers: response.headers(),
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`DELETE request failed: ${url}`, { error, duration });
      throw error;
    }
  }

  /**
   * Build complete URL with query parameters
   */
  private buildUrl(endpoint: string, params?: Record<string, string>): string {
    const url = new URL(endpoint, this.baseUrl);
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        url.searchParams.append(key, value);
      });
    }

    return url.toString();
  }

  /**
   * Parse response based on content type
   */
  private async parseResponse<T>(response: any): Promise<T | null> {
    const contentType = response.headers()['content-type'] || '';

    try {
      if (contentType.includes('application/json')) {
        return await response.json();
      } else if (contentType.includes('text/')) {
        return await response.text();
      } else {
        return await response.body();
      }
    } catch (error) {
      logger.warn('Failed to parse response body', { error });
      return null;
    }
  }

  /**
   * Validate response status
   */
  public validateStatus(response: ApiResponse, expectedStatus: number | number[]): void {
    const expected = Array.isArray(expectedStatus) ? expectedStatus : [expectedStatus];
    
    if (!expected.includes(response.status)) {
      throw new Error(
        `Expected status ${expected.join(' or ')}, but got ${response.status}: ${response.statusText}`
      );
    }
  }

  /**
   * Validate response data structure
   */
  public validateResponseData<T>(
    response: ApiResponse<T>,
    validator: (data: T) => boolean,
    errorMessage?: string
  ): void {
    if (!response.data || !validator(response.data)) {
      throw new Error(errorMessage || 'Response data validation failed');
    }
  }
}