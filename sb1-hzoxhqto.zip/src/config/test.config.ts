import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

/**
 * Test configuration interface
 */
export interface TestConfig {
  baseUrl?: string;
  apiUrl?: string;
  environment: 'local' | 'dev' | 'staging' | 'production';
  timeouts: {
    action: number;
    navigation: number;
    test: number;
  };
  retries: {
    count: number;
    delay: number;
  };
  browser: {
    headless: boolean;
    slowMo: number;
  };
  logging: {
    level: 'error' | 'warn' | 'info' | 'debug';
    enableConsole: boolean;
    enableFile: boolean;
  };
  screenshots: {
    mode: 'off' | 'only-on-failure' | 'on';
    quality: number;
  };
  reports: {
    outputDir: string;
    keepPreviousReports: boolean;
  };
}

/**
 * Get configuration for the specified environment
 */
const getConfig = (): TestConfig => {
  const env = (process.env.TEST_ENV || 'local') as TestConfig['environment'];
  
  const baseConfig: TestConfig = {
    environment: env,
    timeouts: {
      action: 30000,
      navigation: 30000,
      test: 120000,
    },
    retries: {
      count: process.env.CI ? 2 : 0,
      delay: 1000,
    },
    browser: {
      headless: process.env.CI ? true : false,
      slowMo: 0,
    },
    logging: {
      level: 'info',
      enableConsole: true,
      enableFile: true,
    },
    screenshots: {
      mode: 'only-on-failure',
      quality: 80,
    },
    reports: {
      outputDir: './src/reports',
      keepPreviousReports: false,
    },
  };

  // Environment-specific configurations
  const envConfigs: Record<TestConfig['environment'], Partial<TestConfig>> = {
    local: {
      baseUrl: 'http://localhost:5173',
      apiUrl: 'http://localhost:3000/api',
      logging: { ...baseConfig.logging, level: 'debug' },
    },
    dev: {
      baseUrl: 'https://dev.example.com',
      apiUrl: 'https://api-dev.example.com',
    },
    staging: {
      baseUrl: 'https://staging.example.com',
      apiUrl: 'https://api-staging.example.com',
    },
    production: {
      baseUrl: 'https://example.com',
      apiUrl: 'https://api.example.com',
      logging: { ...baseConfig.logging, level: 'error' },
    },
  };

  return { ...baseConfig, ...envConfigs[env] };
};

export const config = getConfig();