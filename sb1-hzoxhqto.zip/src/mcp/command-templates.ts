/**
 * MCP Command Templates and Best Practices Guide
 */

export const MCPCommandTemplates = {
  // Navigation Commands
  navigation: {
    examples: [
      'navigate to "https://example.com"',
      'go to page "/login"',
      'visit the homepage',
      'open new tab and go to "https://google.com"',
    ],
    patterns: [
      'navigate to "{url}"',
      'go to page "{path}"',
      'visit {page_description}',
      'open {target} and go to "{url}"',
    ],
    bestPractices: [
      'Always use full URLs for external sites',
      'Use relative paths for internal navigation',
      'Wait for page load after navigation',
      'Verify page loaded correctly',
    ],
  },

  // Click Actions
  clicking: {
    examples: [
      'click on "Login" button',
      'click on element with id "submit-btn"',
      'tap on the menu icon',
      'click on the first link in the navigation',
    ],
    patterns: [
      'click on "{text}" {element_type}',
      'click on element with {attribute} "{value}"',
      'tap on {description}',
      'click on the {position} {element_type}',
    ],
    bestPractices: [
      'Use descriptive text when possible',
      'Specify element type for clarity',
      'Use position indicators (first, last, second)',
      'Wait for element to be clickable',
    ],
  },

  // Text Input
  typing: {
    examples: [
      'type "john@example.com" into email field',
      'enter "password123" in password input',
      'fill "John Doe" in the name field',
      'clear and type "new value" in search box',
    ],
    patterns: [
      'type "{text}" into {field_description}',
      'enter "{value}" in {input_description}',
      'fill "{data}" in the {field_name} field',
      'clear and type "{text}" in {target}',
    ],
    bestPractices: [
      'Clear field before typing if needed',
      'Use descriptive field names',
      'Handle special characters properly',
      'Verify text was entered correctly',
    ],
  },

  // Verification/Assertions
  verification: {
    examples: [
      'verify page title contains "Dashboard"',
      'check that "Welcome" text is visible',
      'assert element with id "success-message" exists',
      'confirm page URL contains "/profile"',
    ],
    patterns: [
      'verify {property} {condition} "{expected}"',
      'check that "{text}" is {state}',
      'assert {element_description} {condition}',
      'confirm {page_property} {condition} "{value}"',
    ],
    bestPractices: [
      'Use specific assertions',
      'Verify both positive and negative cases',
      'Check element states (visible, enabled, etc.)',
      'Validate data accuracy',
    ],
  },

  // Waiting
  waiting: {
    examples: [
      'wait for "Loading..." to disappear',
      'wait 3 seconds',
      'wait for element with class "data-loaded" to appear',
      'wait for page to load completely',
    ],
    patterns: [
      'wait for "{text}" to {action}',
      'wait {duration} {time_unit}',
      'wait for {element_description} to {state}',
      'wait for {condition}',
    ],
    bestPractices: [
      'Use dynamic waits over fixed delays',
      'Wait for specific conditions',
      'Set reasonable timeout values',
      'Handle loading states properly',
    ],
  },

  // Form Interactions
  forms: {
    examples: [
      'select "United States" from country dropdown',
      'check the "I agree" checkbox',
      'uncheck the newsletter subscription',
      'upload file "test-document.pdf" to file input',
    ],
    patterns: [
      'select "{option}" from {dropdown_description}',
      'check the "{label}" checkbox',
      'uncheck {checkbox_description}',
      'upload file "{filename}" to {input_description}',
    ],
    bestPractices: [
      'Use exact option text for dropdowns',
      'Verify selections were made',
      'Handle file uploads carefully',
      'Test form validation',
    ],
  },

  // Visual Actions
  visual: {
    examples: [
      'take screenshot of current page',
      'capture element with id "chart" as screenshot',
      'scroll to bottom of page',
      'hover over the profile menu',
    ],
    patterns: [
      'take screenshot {scope}',
      'capture {element_description} as screenshot',
      'scroll to {position}',
      'hover over {element_description}',
    ],
    bestPractices: [
      'Take screenshots for visual verification',
      'Scroll elements into view before interaction',
      'Use hover for revealing hidden elements',
      'Capture evidence of test execution',
    ],
  },
};

/**
 * Command validation and suggestion system
 */
export class CommandTemplateHelper {
  /**
   * Get suggestions for a partial command
   */
  public static getSuggestions(partialCommand: string): string[] {
    const suggestions: string[] = [];
    const lowerCommand = partialCommand.toLowerCase();

    Object.values(MCPCommandTemplates).forEach(category => {
      category.examples.forEach(example => {
        if (example.toLowerCase().includes(lowerCommand)) {
          suggestions.push(example);
        }
      });
    });

    return suggestions.slice(0, 10); // Limit to top 10 suggestions
  }

  /**
   * Get best practices for a command type
   */
  public static getBestPractices(commandType: string): string[] {
    const category = Object.values(MCPCommandTemplates).find(cat =>
      cat.examples.some(example => 
        example.toLowerCase().includes(commandType.toLowerCase())
      )
    );

    return category?.bestPractices || [];
  }

  /**
   * Validate command structure
   */
  public static validateCommand(command: string): {
    isValid: boolean;
    category?: string;
    suggestions: string[];
    bestPractices: string[];
  } {
    const lowerCommand = command.toLowerCase();
    let matchedCategory = '';

    // Find matching category
    for (const [categoryName, category] of Object.entries(MCPCommandTemplates)) {
      const hasMatch = category.examples.some(example =>
        this.commandMatches(lowerCommand, example.toLowerCase())
      );
      
      if (hasMatch) {
        matchedCategory = categoryName;
        break;
      }
    }

    return {
      isValid: !!matchedCategory,
      category: matchedCategory,
      suggestions: this.getSuggestions(command),
      bestPractices: this.getBestPractices(command),
    };
  }

  private static commandMatches(command: string, pattern: string): boolean {
    // Simple pattern matching - can be enhanced with regex
    const commandWords = command.split(' ');
    const patternWords = pattern.split(' ');
    
    return commandWords.some(word => 
      patternWords.some(patternWord => 
        patternWord.includes(word) || word.includes(patternWord)
      )
    );
  }
}