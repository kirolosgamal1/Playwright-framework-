import { logger } from '../utils/logger';
import { config } from '../config/test.config';
import { Page } from '@playwright/test';

/**
 * MCP Client for natural language test automation
 */
export class MCPClient {
  private static instance: MCPClient;
  private isConnected: boolean = false;
  private mcpEndpoint: string;

  private constructor() {
    this.mcpEndpoint = process.env.MCP_ENDPOINT || 'http://localhost:3001';
  }

  public static getInstance(): MCPClient {
    if (!MCPClient.instance) {
      MCPClient.instance = new MCPClient();
    }
    return MCPClient.instance;
  }

  /**
   * Connect to MCP server
   */
  public async connect(): Promise<void> {
    try {
      const response = await fetch(`${this.mcpEndpoint}/health`);
      if (response.ok) {
        this.isConnected = true;
        logger.info('Connected to MCP server');
      } else {
        throw new Error('MCP server not responding');
      }
    } catch (error) {
      logger.warn('MCP server not available, falling back to traditional testing', { error });
      this.isConnected = false;
    }
  }

  /**
   * Execute natural language command
   */
  public async executeCommand(
    page: Page,
    command: string,
    context?: Record<string, any>
  ): Promise<MCPCommandResult> {
    if (!this.isConnected) {
      await this.connect();
    }

    if (!this.isConnected) {
      throw new Error('MCP server is not available');
    }

    const startTime = Date.now();
    
    try {
      const response = await fetch(`${this.mcpEndpoint}/execute`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          command,
          context: {
            url: page.url(),
            viewport: await page.viewportSize(),
            ...context,
          },
          options: {
            screenshot: true,
            timeout: config.timeouts.action,
          },
        }),
      });

      const result = await response.json();
      const duration = Date.now() - startTime;

      logger.info(`MCP command executed: "${command}"`, {
        duration,
        success: result.success,
      });

      return {
        success: result.success,
        message: result.message,
        data: result.data,
        screenshot: result.screenshot,
        duration,
        command,
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`MCP command failed: "${command}"`, { error, duration });
      
      return {
        success: false,
        message: `Command execution failed: ${error}`,
        data: null,
        screenshot: null,
        duration,
        command,
      };
    }
  }

  /**
   * Execute batch of commands
   */
  public async executeBatch(
    page: Page,
    commands: MCPCommand[],
    options?: { stopOnError?: boolean }
  ): Promise<MCPBatchResult> {
    const results: MCPCommandResult[] = [];
    const startTime = Date.now();

    for (const cmd of commands) {
      try {
        const result = await this.executeCommand(page, cmd.command, cmd.context);
        results.push(result);

        if (!result.success && options?.stopOnError) {
          break;
        }

        // Add delay between commands if specified
        if (cmd.delay) {
          await new Promise(resolve => setTimeout(resolve, cmd.delay));
        }
      } catch (error) {
        const failedResult: MCPCommandResult = {
          success: false,
          message: `Batch command failed: ${error}`,
          data: null,
          screenshot: null,
          duration: 0,
          command: cmd.command,
        };
        results.push(failedResult);

        if (options?.stopOnError) {
          break;
        }
      }
    }

    const totalDuration = Date.now() - startTime;
    const successCount = results.filter(r => r.success).length;

    logger.info('MCP batch execution completed', {
      totalCommands: commands.length,
      successCount,
      failedCount: results.length - successCount,
      totalDuration,
    });

    return {
      results,
      totalDuration,
      successCount,
      failedCount: results.length - successCount,
    };
  }

  /**
   * Validate command syntax
   */
  public validateCommand(command: string): MCPValidationResult {
    const validationRules = [
      { pattern: /^(click|tap)\s+/i, type: 'action' },
      { pattern: /^(type|enter|input)\s+/i, type: 'input' },
      { pattern: /^(navigate|go)\s+to\s+/i, type: 'navigation' },
      { pattern: /^(wait|pause)\s+/i, type: 'wait' },
      { pattern: /^(verify|check|assert)\s+/i, type: 'assertion' },
      { pattern: /^(scroll)\s+/i, type: 'scroll' },
      { pattern: /^(hover)\s+/i, type: 'hover' },
      { pattern: /^(screenshot|capture)\s*/i, type: 'screenshot' },
    ];

    const matchedRule = validationRules.find(rule => rule.pattern.test(command));
    
    return {
      isValid: !!matchedRule,
      commandType: matchedRule?.type || 'unknown',
      suggestions: this.getCommandSuggestions(command),
    };
  }

  private getCommandSuggestions(command: string): string[] {
    const suggestions: string[] = [];
    const lowerCommand = command.toLowerCase();

    if (lowerCommand.includes('click') || lowerCommand.includes('button')) {
      suggestions.push('click on "button text" or click on element with id "element-id"');
    }
    
    if (lowerCommand.includes('type') || lowerCommand.includes('input')) {
      suggestions.push('type "text" into field "field name" or enter "value" in input');
    }
    
    if (lowerCommand.includes('navigate') || lowerCommand.includes('go')) {
      suggestions.push('navigate to "https://example.com" or go to page "/login"');
    }

    return suggestions;
  }
}

export interface MCPCommand {
  command: string;
  context?: Record<string, any>;
  delay?: number;
  description?: string;
}

export interface MCPCommandResult {
  success: boolean;
  message: string;
  data: any;
  screenshot: string | null;
  duration: number;
  command: string;
}

export interface MCPBatchResult {
  results: MCPCommandResult[];
  totalDuration: number;
  successCount: number;
  failedCount: number;
}

export interface MCPValidationResult {
  isValid: boolean;
  commandType: string;
  suggestions: string[];
}