import { test, expect, Page } from '@playwright/test';
import { MCPClient, MCPCommand } from './mcp-client';
import { logger } from '../utils/logger';
import fs from 'fs';
import path from 'path';

/**
 * Natural Language Test Runner using MCP
 */
export class NaturalLanguageTest {
  private mcpClient: MCPClient;
  private page: Page;
  private testName: string;

  constructor(page: Page, testName: string) {
    this.mcpClient = MCPClient.getInstance();
    this.page = page;
    this.testName = testName;
  }

  /**
   * Execute test from JSON file
   */
  public static async fromJsonFile(page: Page, filePath: string): Promise<NaturalLanguageTest> {
    const fullPath = path.resolve(filePath);
    
    if (!fs.existsSync(fullPath)) {
      throw new Error(`Test file not found: ${fullPath}`);
    }

    const testData = JSON.parse(fs.readFileSync(fullPath, 'utf-8'));
    const nlTest = new NaturalLanguageTest(page, testData.name || path.basename(filePath));
    
    await nlTest.executeTestSuite(testData);
    return nlTest;
  }

  /**
   * Execute a single natural language command
   */
  public async executeCommand(command: string, context?: Record<string, any>): Promise<void> {
    logger.step(this.testName, `Executing: ${command}`);
    
    const result = await this.mcpClient.executeCommand(this.page, command, context);
    
    if (!result.success) {
      throw new Error(`Command failed: ${command} - ${result.message}`);
    }

    logger.info(`Command completed successfully: ${command}`, {
      duration: result.duration,
    });
  }

  /**
   * Execute multiple commands in sequence
   */
  public async executeCommands(commands: string[] | MCPCommand[]): Promise<void> {
    const mcpCommands: MCPCommand[] = commands.map(cmd => 
      typeof cmd === 'string' ? { command: cmd } : cmd
    );

    const result = await this.mcpClient.executeBatch(this.page, mcpCommands, {
      stopOnError: true,
    });

    if (result.failedCount > 0) {
      const failedCommands = result.results
        .filter(r => !r.success)
        .map(r => r.command);
      
      throw new Error(`${result.failedCount} commands failed: ${failedCommands.join(', ')}`);
    }

    logger.info(`All ${result.successCount} commands executed successfully`);
  }

  /**
   * Execute complete test suite from JSON structure
   */
  public async executeTestSuite(testSuite: NaturalLanguageTestSuite): Promise<void> {
    logger.info(`Starting natural language test suite: ${testSuite.name}`);

    // Execute setup commands
    if (testSuite.setup && testSuite.setup.length > 0) {
      logger.step(this.testName, 'Executing setup commands');
      await this.executeCommands(testSuite.setup);
    }

    // Execute main test steps
    for (const step of testSuite.steps) {
      logger.step(this.testName, `Step: ${step.description || step.command}`);
      
      try {
        await this.executeCommand(step.command, step.context);
        
        // Execute assertions if present
        if (step.assertions) {
          for (const assertion of step.assertions) {
            await this.executeCommand(assertion);
          }
        }
      } catch (error) {
        if (step.continueOnError) {
          logger.warn(`Step failed but continuing: ${step.command}`, { error });
        } else {
          throw error;
        }
      }
    }

    // Execute cleanup commands
    if (testSuite.cleanup && testSuite.cleanup.length > 0) {
      logger.step(this.testName, 'Executing cleanup commands');
      try {
        await this.executeCommands(testSuite.cleanup);
      } catch (error) {
        logger.warn('Cleanup commands failed', { error });
      }
    }

    logger.info(`Natural language test suite completed: ${testSuite.name}`);
  }

  /**
   * Generate traditional Playwright test from natural language commands
   */
  public static generatePlaywrightTest(
    testSuite: NaturalLanguageTestSuite,
    outputPath: string
  ): void {
    const testCode = `
import { test, expect } from '@playwright/test';
import { NaturalLanguageTest } from '../mcp/natural-language-test';

test.describe('${testSuite.name}', () => {
  test('${testSuite.description || testSuite.name} @mcp @generated', async ({ page }) => {
    const nlTest = new NaturalLanguageTest(page, '${testSuite.name}');
    
    // Generated from natural language test suite
    const testSuite = ${JSON.stringify(testSuite, null, 6)};
    
    await nlTest.executeTestSuite(testSuite);
  });
});
`;

    fs.writeFileSync(outputPath, testCode);
    logger.info(`Generated Playwright test: ${outputPath}`);
  }
}

export interface NaturalLanguageTestSuite {
  name: string;
  description?: string;
  tags?: string[];
  setup?: MCPCommand[];
  steps: NaturalLanguageTestStep[];
  cleanup?: MCPCommand[];
  metadata?: {
    author?: string;
    created?: string;
    version?: string;
    environment?: string;
  };
}

export interface NaturalLanguageTestStep {
  command: string;
  description?: string;
  context?: Record<string, any>;
  assertions?: string[];
  continueOnError?: boolean;
  screenshot?: boolean;
}