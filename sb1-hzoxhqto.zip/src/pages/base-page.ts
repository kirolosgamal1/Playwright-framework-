import { Page, Locator, expect } from '@playwright/test';
import { logger } from '../utils/logger';
import { config } from '../config/test.config';

/**
 * Base page class implementing common page functionality
 */
export abstract class BasePage {
  protected page: Page;
  protected baseUrl: string;

  constructor(page: Page) {
    this.page = page;
    this.baseUrl = config.baseUrl || '';
  }

  /**
   * Navigate to the page
   */
  public async navigate(url?: string): Promise<void> {
    const targetUrl = url || this.getUrl();
    logger.step(this.constructor.name, `Navigating to ${targetUrl}`);
    
    await this.page.goto(targetUrl, {
      waitUntil: 'domcontentloaded',
      timeout: config.timeouts.navigation,
    });
    
    await this.waitForPageLoad();
  }

  /**
   * Get the page URL (to be implemented by child classes)
   */
  protected abstract getUrl(): string;

  /**
   * Wait for page to load completely
   */
  protected async waitForPageLoad(): Promise<void> {
    await this.page.waitForLoadState('networkidle');
  }

  /**
   * Wait for element to be visible
   */
  protected async waitForElement(locator: Locator, timeout?: number): Promise<void> {
    await locator.waitFor({
      state: 'visible',
      timeout: timeout || config.timeouts.action,
    });
  }

  /**
   * Click element with retry logic
   */
  protected async clickElement(locator: Locator, options?: { force?: boolean }): Promise<void> {
    await this.waitForElement(locator);
    await locator.click(options);
    logger.debug(`Clicked element: ${locator}`);
  }

  /**
   * Fill input field
   */
  protected async fillInput(locator: Locator, value: string, options?: { clear?: boolean }): Promise<void> {
    await this.waitForElement(locator);
    
    if (options?.clear) {
      await locator.clear();
    }
    
    await locator.fill(value);
    logger.debug(`Filled input with value: ${value}`);
  }

  /**
   * Get element text
   */
  protected async getElementText(locator: Locator): Promise<string> {
    await this.waitForElement(locator);
    const text = await locator.textContent();
    return text || '';
  }

  /**
   * Check if element is visible
   */
  protected async isElementVisible(locator: Locator): Promise<boolean> {
    try {
      await this.waitForElement(locator);
      return await locator.isVisible();
    } catch {
      return false;
    }
  }

  /**
   * Take screenshot of the page
   */
  public async takeScreenshot(name?: string): Promise<string> {
    const screenshotName = name || `${this.constructor.name}_${Date.now()}`;
    const path = `./src/reports/screenshots/${screenshotName}.png`;
    
    await this.page.screenshot({
      path,
      fullPage: true,
      quality: config.screenshots.quality,
    });
    
    logger.info(`Screenshot saved: ${path}`);
    return path;
  }

  /**
   * Wait for API response
   */
  protected async waitForApiResponse(urlPattern: string | RegExp, timeout?: number): Promise<any> {
    const responsePromise = this.page.waitForResponse(
      response => {
        const url = response.url();
        return typeof urlPattern === 'string' 
          ? url.includes(urlPattern)
          : urlPattern.test(url);
      },
      { timeout: timeout || config.timeouts.action }
    );

    const response = await responsePromise;
    const responseData = await response.json().catch(() => null);
    
    logger.api(
      response.request().method(),
      response.url(),
      response.status(),
      0 // TODO: Add duration tracking
    );

    return responseData;
  }

  /**
   * Verify page title
   */
  public async verifyTitle(expectedTitle: string): Promise<void> {
    await expect(this.page).toHaveTitle(expectedTitle);
    logger.step(this.constructor.name, `Verified page title: ${expectedTitle}`);
  }

  /**
   * Verify page URL
   */
  public async verifyUrl(expectedUrl: string | RegExp): Promise<void> {
    await expect(this.page).toHaveURL(expectedUrl);
    logger.step(this.constructor.name, `Verified page URL: ${expectedUrl}`);
  }

  /**
   * Scroll to element
   */
  protected async scrollToElement(locator: Locator): Promise<void> {
    await locator.scrollIntoViewIfNeeded();
    logger.debug(`Scrolled to element: ${locator}`);
  }

  /**
   * Hover over element
   */
  protected async hoverElement(locator: Locator): Promise<void> {
    await this.waitForElement(locator);
    await locator.hover();
    logger.debug(`Hovered over element: ${locator}`);
  }

  /**
   * Double click element
   */
  protected async doubleClickElement(locator: Locator): Promise<void> {
    await this.waitForElement(locator);
    await locator.dblclick();
    logger.debug(`Double clicked element: ${locator}`);
  }

  /**
   * Right click element
   */
  protected async rightClickElement(locator: Locator): Promise<void> {
    await this.waitForElement(locator);
    await locator.click({ button: 'right' });
    logger.debug(`Right clicked element: ${locator}`);
  }

  /**
   * Select option from dropdown
   */
  protected async selectOption(locator: Locator, option: string | { label?: string; value?: string; index?: number }): Promise<void> {
    await this.waitForElement(locator);
    
    if (typeof option === 'string') {
      await locator.selectOption(option);
    } else {
      if (option.value) await locator.selectOption({ value: option.value });
      else if (option.label) await locator.selectOption({ label: option.label });
      else if (option.index !== undefined) await locator.selectOption({ index: option.index });
    }
    
    logger.debug(`Selected option: ${JSON.stringify(option)}`);
  }

  /**
   * Upload file
   */
  protected async uploadFile(locator: Locator, filePath: string): Promise<void> {
    await this.waitForElement(locator);
    await locator.setInputFiles(filePath);
    logger.debug(`Uploaded file: ${filePath}`);
  }

  /**
   * Get current URL
   */
  public getCurrentUrl(): string {
    return this.page.url();
  }

  /**
   * Refresh page
   */
  public async refreshPage(): Promise<void> {
    await this.page.reload();
    await this.waitForPageLoad();
    logger.step(this.constructor.name, 'Page refreshed');
  }

  /**
   * Go back in browser history
   */
  public async goBack(): Promise<void> {
    await this.page.goBack();
    await this.waitForPageLoad();
    logger.step(this.constructor.name, 'Navigated back');
  }

  /**
   * Go forward in browser history
   */
  public async goForward(): Promise<void> {
    await this.page.goForward();
    await this.waitForPageLoad();
    logger.step(this.constructor.name, 'Navigated forward');
  }
}

export { BasePage }