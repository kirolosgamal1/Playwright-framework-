import { Page, Locator } from '@playwright/test';
import { BasePage } from './base-page';

/**
 * Home page object following Page Object Model pattern
 */
export class HomePage extends BasePage {
  // Page elements
  private readonly heroTitle: Locator;
  private readonly heroSubtitle: Locator;
  private readonly ctaButton: Locator;
  private readonly navigationMenu: Locator;
  private readonly logo: Locator;

  constructor(page: Page) {
    super(page);
    
    // Initialize locators
    this.heroTitle = page.locator('h1').first();
    this.heroSubtitle = page.locator('p').first();
    this.ctaButton = page.locator('button', { hasText: 'Get Started' });
    this.navigationMenu = page.locator('nav');
    this.logo = page.locator('[data-testid="logo"]');
  }

  /**
   * Get the page URL
   */
  protected getUrl(): string {
    return '/';
  }

  /**
   * Verify page elements are visible
   */
  public async verifyPageElements(): Promise<void> {
    await this.waitForElement(this.heroTitle);
    await this.waitForElement(this.heroSubtitle);
    await this.waitForElement(this.ctaButton);
  }

  /**
   * Get hero title text
   */
  public async getHeroTitle(): Promise<string> {
    return await this.getElementText(this.heroTitle);
  }

  /**
   * Get hero subtitle text
   */
  public async getHeroSubtitle(): Promise<string> {
    return await this.getElementText(this.heroSubtitle);
  }

  /**
   * Click CTA button
   */
  public async clickCtaButton(): Promise<void> {
    await this.clickElement(this.ctaButton);
  }

  /**
   * Check if navigation menu is visible
   */
  public async isNavigationVisible(): Promise<boolean> {
    return await this.isElementVisible(this.navigationMenu);
  }

  /**
   * Click logo
   */
  public async clickLogo(): Promise<void> {
    await this.clickElement(this.logo);
  }

  /**
   * Wait for page to be fully loaded
   */
  public async waitForHomePageLoad(): Promise<void> {
    await this.waitForPageLoad();
    await this.verifyPageElements();
  }
}