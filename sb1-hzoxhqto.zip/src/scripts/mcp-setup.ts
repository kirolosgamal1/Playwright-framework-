import { logger } from '../utils/logger';
import { mcpTestGenerator } from '../utils/mcp-test-generator';

/**
 * Setup script for MCP integration
 */
async function setupMCP() {
  logger.info('Setting up MCP integration...');

  try {
    // Validate existing test files
    logger.info('Validating existing natural language tests...');
    const validationResults = mcpTestGenerator.validateAllTests();
    
    const validTests = validationResults.filter(r => r.isValid);
    const invalidTests = validationResults.filter(r => !r.isValid);

    logger.info(`Validation complete: ${validTests.length} valid, ${invalidTests.length} invalid tests`);

    if (invalidTests.length > 0) {
      logger.warn('Invalid tests found:');
      invalidTests.forEach(result => {
        logger.warn(`${result.filePath}: ${result.errors.join(', ')}`);
      });
    }

    // Generate Playwright tests from JSON files
    logger.info('Generating Playwright tests from natural language definitions...');
    mcpTestGenerator.generateAllTests();

    // Show command statistics
    const stats = mcpTestGenerator.getCommandStatistics();
    logger.info('Command usage statistics:', {
      totalTests: stats.totalTests,
      totalCommands: stats.totalCommands,
      topCommands: stats.mostUsedCommands.slice(0, 5),
    });

    logger.info('MCP setup completed successfully!');
    
    // Print usage instructions
    console.log('\n📋 MCP Integration Setup Complete!');
    console.log('\n🚀 Quick Start:');
    console.log('1. Start MCP server: npm run mcp:server (if you have one)');
    console.log('2. Run MCP tests: npm run test:mcp');
    console.log('3. Create new test: Use JSON files in src/test-data/natural-language-tests/');
    console.log('\n📝 Example Commands:');
    console.log('- navigate to "https://example.com"');
    console.log('- click on "Login" button');
    console.log('- type "user@example.com" into email field');
    console.log('- verify page title contains "Dashboard"');
    console.log('\n📁 Files Created:');
    console.log('- src/mcp/ - MCP client and natural language test runner');
    console.log('- src/test-data/natural-language-tests/ - JSON test definitions');
    console.log('- src/tests/generated/ - Auto-generated Playwright tests');

  } catch (error) {
    logger.error('MCP setup failed', { error });
    process.exit(1);
  }
}

// Run setup if called directly
if (require.main === module) {
  setupMCP();
}

export { setupMCP };