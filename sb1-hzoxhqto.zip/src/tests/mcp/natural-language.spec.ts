import { test, expect } from '@playwright/test';
import { NaturalLanguageTest } from '../../mcp/natural-language-test';
import { logger } from '../../utils/logger';

test.describe('Natural Language Tests via MCP', () => {
  test('should execute simple natural language commands @mcp @smoke', async ({ page }) => {
    const nlTest = new NaturalLanguageTest(page, 'Simple MCP Test');

    // Execute individual commands
    await nlTest.executeCommand('navigate to "/"');
    await nlTest.executeCommand('wait for page to load completely');
    await nlTest.executeCommand('take screenshot of current page');
    await nlTest.executeCommand('verify page title contains "Playwright"');

    logger.info('Simple natural language test completed successfully');
  });

  test('should execute batch commands @mcp @regression', async ({ page }) => {
    const nlTest = new NaturalLanguageTest(page, 'Batch Commands Test');

    const commands = [
      'navigate to "/"',
      'wait 2 seconds',
      'scroll to bottom of page',
      'take screenshot of current page',
      'scroll to top of page',
    ];

    await nlTest.executeCommands(commands);
    logger.info('Batch commands test completed successfully');
  });

  test('should load and execute test from JSON file @mcp @data-driven', async ({ page }) => {
    // This test demonstrates loading from JSON file
    // In practice, you would have actual JSON files in your test data directory
    const mockTestSuite = {
      name: 'Homepage Navigation Test',
      description: 'Test basic homepage navigation and interactions',
      setup: [
        { command: 'navigate to "/"' },
        { command: 'wait for page to load completely' },
      ],
      steps: [
        {
          command: 'verify page title contains "Playwright"',
          description: 'Check page title is correct',
        },
        {
          command: 'take screenshot of current page',
          description: 'Capture homepage screenshot',
        },
        {
          command: 'scroll to bottom of page',
          description: 'Scroll to see full page content',
        },
      ],
      cleanup: [
        { command: 'take screenshot of current page' },
      ],
    };

    const nlTest = new NaturalLanguageTest(page, mockTestSuite.name);
    await nlTest.executeTestSuite(mockTestSuite);

    logger.info('JSON-driven test completed successfully');
  });

  test('should handle command failures gracefully @mcp @error-handling', async ({ page }) => {
    const nlTest = new NaturalLanguageTest(page, 'Error Handling Test');

    // Navigate to a valid page first
    await nlTest.executeCommand('navigate to "/"');

    // Test with a command that might fail
    try {
      await nlTest.executeCommand('click on "NonExistentButton" button');
    } catch (error) {
      // Expected to fail - verify error handling works
      expect(error).toBeDefined();
      logger.info('Error handling test passed - command failed as expected');
    }
  });
});