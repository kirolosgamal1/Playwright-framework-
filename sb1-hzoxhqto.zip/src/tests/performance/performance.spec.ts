import { test, expect } from '@playwright/test';
import { HomePage } from '../../pages/home-page';
import { logger } from '../../utils/logger';
import { PerformanceMetrics } from '../../types';

test.describe('Performance Tests', () => {
  let homePage: HomePage;

  test.beforeEach(async ({ page }) => {
    homePage = new HomePage(page);
  });

  test('should meet performance benchmarks @performance @critical', async ({ page }) => {
    // Start performance measurement
    const startTime = Date.now();
    
    // Navigate to page
    await homePage.navigate();
    
    // Measure page load performance
    const performanceMetrics = await page.evaluate(() => {
      const perfData = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
      return {
        loadTime: perfData.loadEventEnd - perfData.loadEventStart,
        domContentLoaded: perfData.domContentLoadedEventEnd - perfData.domContentLoadedEventStart,
        firstContentfulPaint: 0, // Would need additional setup for real FCP
        largestContentfulPaint: 0, // Would need additional setup for real LCP
        timeToInteractive: perfData.loadEventEnd - perfData.fetchStart,
      };
    });

    const totalLoadTime = Date.now() - startTime;

    // Performance assertions
    expect(totalLoadTime).toBeLessThan(5000); // Page should load within 5 seconds
    expect(performanceMetrics.timeToInteractive).toBeLessThan(3000); // TTI should be under 3 seconds

    logger.info('Performance metrics collected', {
      totalLoadTime,
      ...performanceMetrics,
    });
  });

  test('should handle large datasets efficiently @performance @scalability', async ({ page }) => {
    // Simulate loading page with large amount of data
    await page.route('**/api/large-dataset', async route => {
      // Mock large dataset
      const largeData = Array.from({ length: 1000 }, (_, i) => ({
        id: i,
        name: `Item ${i}`,
        description: `Description for item ${i}`,
      }));
      
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify(largeData),
      });
    });

    const startTime = Date.now();
    await homePage.navigate();
    
    // Simulate data loading
    await page.evaluate(() => {
      return fetch('/api/large-dataset').then(r => r.json());
    });

    const processingTime = Date.now() - startTime;
    
    // Assert performance with large dataset
    expect(processingTime).toBeLessThan(2000);
    
    logger.info('Large dataset performance test completed', {
      processingTime,
      itemCount: 1000,
    });
  });

  test('should maintain performance under load @performance @stress', async ({ page }) => {
    const iterations = 5;
    const loadTimes: number[] = [];

    for (let i = 0; i < iterations; i++) {
      const startTime = Date.now();
      
      if (i > 0) {
        await page.reload();
      } else {
        await homePage.navigate();
      }
      
      await homePage.waitForHomePageLoad();
      
      const loadTime = Date.now() - startTime;
      loadTimes.push(loadTime);
      
      logger.debug(`Load iteration ${i + 1}: ${loadTime}ms`);
    }

    const averageLoadTime = loadTimes.reduce((a, b) => a + b, 0) / loadTimes.length;
    const maxLoadTime = Math.max(...loadTimes);
    const minLoadTime = Math.min(...loadTimes);

    // Performance consistency assertions
    expect(averageLoadTime).toBeLessThan(3000);
    expect(maxLoadTime - minLoadTime).toBeLessThan(2000); // Load time should be consistent

    logger.info('Load performance stress test completed', {
      iterations,
      averageLoadTime,
      maxLoadTime,
      minLoadTime,
      loadTimes,
    });
  });

  test('should optimize resource loading @performance @resources', async ({ page }) => {
    const resourceMetrics: Array<{ name: string; size: number; duration: number }> = [];

    // Monitor resource loading
    page.on('response', async (response) => {
      if (response.request().resourceType() !== 'document') {
        try {
          const size = parseInt(response.headers()['content-length'] || '0', 10);
          const timing = response.request().timing();
          const duration = timing?.responseEnd ? timing.responseEnd - timing.requestStart : 0;
          
          resourceMetrics.push({
            name: response.url(),
            size,
            duration,
          });
        } catch (error) {
          // Ignore timing errors
        }
      }
    });

    await homePage.navigate();
    await homePage.waitForHomePageLoad();

    // Analyze resource metrics
    const totalSize = resourceMetrics.reduce((sum, resource) => sum + resource.size, 0);
    const slowResources = resourceMetrics.filter(resource => resource.duration > 1000);

    logger.info('Resource loading metrics', {
      totalResources: resourceMetrics.length,
      totalSize: `${(totalSize / 1024).toFixed(2)} KB`,
      slowResources: slowResources.length,
      slowResourcesList: slowResources.map(r => ({ name: r.name, duration: r.duration })),
    });

    // Resource optimization assertions
    expect(slowResources.length).toBeLessThan(3); // No more than 2 slow resources
    expect(totalSize).toBeLessThan(1024 * 1024); // Total size under 1MB
  });
});