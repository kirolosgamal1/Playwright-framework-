import { test, expect } from '@playwright/test';
import { HomePage } from '../../pages/home-page';
import { testDataFactory } from '../../utils/test-data-factory';
import { logger } from '../../utils/logger';

test.describe('Home Page Tests', () => {
  let homePage: HomePage;

  test.beforeEach(async ({ page }) => {
    homePage = new HomePage(page);
    await homePage.navigate();
  });

  test('should load home page successfully @smoke', async ({ page }) => {
    // Verify page loads
    await homePage.waitForHomePageLoad();
    
    // Verify page title
    await expect(page).toHaveTitle(/Vite \+ React \+ TS/);
    
    // Verify URL
    await homePage.verifyUrl(/.*\/$/);
    
    logger.info('Home page loaded successfully');
  });

  test('should display main page elements @regression', async () => {
    // Verify page elements are visible
    await homePage.verifyPageElements();
    
    // Check navigation visibility
    const isNavVisible = await homePage.isNavigationVisible();
    expect(isNavVisible).toBe(true);
    
    logger.info('All main page elements are visible');
  });

  test('should handle page interactions @functional', async () => {
    // Wait for page load
    await homePage.waitForHomePageLoad();
    
    // Take screenshot for visual verification
    await homePage.takeScreenshot('home-page-initial');
    
    // Test page refresh
    await homePage.refreshPage();
    await homePage.waitForHomePageLoad();
    
    logger.info('Page interactions completed successfully');
  });

  test('should be responsive on mobile viewport @responsive', async ({ page }) => {
    // Set mobile viewport
    await page.setViewportSize({ width: 375, height: 667 });
    
    // Verify page elements still visible
    await homePage.verifyPageElements();
    
    // Take mobile screenshot
    await homePage.takeScreenshot('home-page-mobile');
    
    logger.info('Mobile responsiveness verified');
  });

  test.afterEach(async ({ page }, testInfo) => {
    if (testInfo.status !== testInfo.expectedStatus) {
      // Take screenshot on failure
      const screenshotPath = await homePage.takeScreenshot(`failure-${testInfo.title.replace(/\s+/g, '-')}`);
      logger.error(`Test failed, screenshot saved: ${screenshotPath}`);
    }
  });
});