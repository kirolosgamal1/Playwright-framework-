import { test, expect } from '@playwright/test';
import { HomePage } from '../../pages/home-page';
import { logger } from '../../utils/logger';

test.describe('Visual Regression Tests', () => {
  let homePage: HomePage;

  test.beforeEach(async ({ page }) => {
    homePage = new HomePage(page);
    await homePage.navigate();
  });

  test('should match home page visual snapshot @visual @regression', async ({ page }) => {
    // Wait for page to load completely
    await homePage.waitForHomePageLoad();
    
    // Wait for any animations to complete
    await page.waitForTimeout(1000);
    
    // Take full page screenshot and compare
    await expect(page).toHaveScreenshot('home-page-full.png', {
      fullPage: true,
      animations: 'disabled',
    });
    
    logger.info('Visual regression test completed for home page');
  });

  test('should match home page header visual snapshot @visual', async ({ page }) => {
    await homePage.waitForHomePageLoad();
    
    // Take screenshot of specific element
    const header = page.locator('header').first();
    if (await header.count() > 0) {
      await expect(header).toHaveScreenshot('home-page-header.png');
    } else {
      // If no header, take top portion of page
      await expect(page.locator('body')).toHaveScreenshot('home-page-top.png', {
        clip: { x: 0, y: 0, width: 1920, height: 400 }
      });
    }
    
    logger.info('Visual regression test completed for header');
  });

  test('should match mobile viewport visual snapshot @visual @mobile', async ({ page }) => {
    // Set mobile viewport
    await page.setViewportSize({ width: 375, height: 667 });
    
    await homePage.waitForHomePageLoad();
    await page.waitForTimeout(1000);
    
    // Take mobile screenshot
    await expect(page).toHaveScreenshot('home-page-mobile.png', {
      fullPage: true,
      animations: 'disabled',
    });
    
    logger.info('Visual regression test completed for mobile viewport');
  });

  test('should match dark theme visual snapshot @visual @theme', async ({ page }) => {
    // Add dark theme class (if your app supports it)
    await page.addStyleTag({
      content: `
        body { 
          background-color: #1a1a1a !important; 
          color: #ffffff !important; 
        }
      `
    });
    
    await homePage.waitForHomePageLoad();
    await page.waitForTimeout(1000);
    
    await expect(page).toHaveScreenshot('home-page-dark-theme.png', {
      fullPage: true,
      animations: 'disabled',
    });
    
    logger.info('Visual regression test completed for dark theme');
  });

  test('should detect visual changes in hover states @visual @interaction', async ({ page }) => {
    await homePage.waitForHomePageLoad();
    
    // Find interactive elements
    const buttons = page.locator('button');
    const links = page.locator('a');
    
    // Test button hover states
    const buttonCount = await buttons.count();
    if (buttonCount > 0) {
      const firstButton = buttons.first();
      await firstButton.hover();
      await page.waitForTimeout(500);
      
      await expect(firstButton).toHaveScreenshot('button-hover-state.png');
    }
    
    // Test link hover states
    const linkCount = await links.count();
    if (linkCount > 0) {
      const firstLink = links.first();
      await firstLink.hover();
      await page.waitForTimeout(500);
      
      await expect(firstLink).toHaveScreenshot('link-hover-state.png');
    }
    
    logger.info('Visual regression test completed for hover states');
  });
});