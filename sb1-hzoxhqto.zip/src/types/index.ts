/**
 * Common types and interfaces for the test framework
 */

export interface User {
  id?: string;
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  role?: 'admin' | 'user' | 'guest';
}

export interface TestData {
  users: {
    valid: User;
    invalid: User;
    admin: User;
  };
  urls: {
    home: string;
    login: string;
    dashboard: string;
    profile: string;
  };
}

export interface ApiResponse<T = any> {
  status: number;
  statusText: string;
  data?: T;
  error?: string;
  headers: Record<string, string>;
}

export interface PerformanceMetrics {
  loadTime: number;
  domContentLoaded: number;
  firstContentfulPaint: number;
  largestContentfulPaint: number;
  timeToInteractive: number;
}

export interface VisualTestResult {
  testName: string;
  passed: boolean;
  diff?: {
    pixels: number;
    percentage: number;
  };
  screenshotPath: string;
}

export interface TestContext {
  testInfo: {
    title: string;
    file: string;
    project: string;
    retry: number;
  };
  performance: PerformanceMetrics;
  screenshots: string[];
}

export type LogLevel = 'error' | 'warn' | 'info' | 'debug';

export interface LogEntry {
  level: LogLevel;
  message: string;
  timestamp: Date;
  metadata?: Record<string, any>;
}