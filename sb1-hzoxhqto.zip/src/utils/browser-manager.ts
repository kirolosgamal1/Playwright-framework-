import { Browser, BrowserContext, Page, chromium, firefox, webkit } from '@playwright/test';
import { config } from '../config/test.config';
import { logger } from './logger';

/**
 * Browser manager implementing Singleton pattern for browser/context management
 */
class BrowserManager {
  private static instance: BrowserManager;
  private browsers: Map<string, Browser> = new Map();
  private contexts: Map<string, BrowserContext> = new Map();

  private constructor() {}

  /**
   * Get singleton instance of BrowserManager
   */
  public static getInstance(): BrowserManager {
    if (!BrowserManager.instance) {
      BrowserManager.instance = new BrowserManager();
    }
    return BrowserManager.instance;
  }

  /**
   * Launch a browser instance
   */
  public async launchBrowser(browserType: 'chromium' | 'firefox' | 'webkit' = 'chromium'): Promise<Browser> {
    if (this.browsers.has(browserType)) {
      return this.browsers.get(browserType)!;
    }

    logger.info(`Launching ${browserType} browser`);

    let browser: Browser;
    const launchOptions = {
      headless: config.browser.headless,
      slowMo: config.browser.slowMo,
    };

    switch (browserType) {
      case 'firefox':
        browser = await firefox.launch(launchOptions);
        break;
      case 'webkit':
        browser = await webkit.launch(launchOptions);
        break;
      default:
        browser = await chromium.launch(launchOptions);
    }

    this.browsers.set(browserType, browser);
    return browser;
  }

  /**
   * Create a new browser context
   */
  public async createContext(
    browser: Browser,
    options?: Parameters<Browser['newContext']>[0]
  ): Promise<BrowserContext> {
    const contextId = `context_${Date.now()}_${Math.random()}`;
    
    const context = await browser.newContext({
      viewport: { width: 1920, height: 1080 },
      recordVideo: config.screenshots.mode !== 'off' ? { dir: './src/reports/videos' } : undefined,
      ...options,
    });

    // Add context event listeners
    context.on('page', (page) => {
      page.on('console', (msg) => {
        logger.debug(`Console ${msg.type()}: ${msg.text()}`);
      });

      page.on('pageerror', (error) => {
        logger.error('Page error:', { error: error.message });
      });

      page.on('requestfailed', (request) => {
        logger.warn('Request failed:', {
          url: request.url(),
          failure: request.failure()?.errorText,
        });
      });
    });

    this.contexts.set(contextId, context);
    return context;
  }

  /**
   * Close all browser contexts
   */
  public async closeAllContexts(): Promise<void> {
    for (const [id, context] of this.contexts) {
      await context.close();
      this.contexts.delete(id);
    }
  }

  /**
   * Close all browsers
   */
  public async closeAllBrowsers(): Promise<void> {
    await this.closeAllContexts();
    
    for (const [type, browser] of this.browsers) {
      await browser.close();
      this.browsers.delete(type);
    }
  }

  /**
   * Get browser instance
   */
  public getBrowser(browserType: string): Browser | undefined {
    return this.browsers.get(browserType);
  }

  /**
   * Take screenshot of the page
   */
  public async takeScreenshot(page: Page, name: string): Promise<string> {
    const screenshotPath = `./src/reports/screenshots/${name}_${Date.now()}.png`;
    
    await page.screenshot({
      path: screenshotPath,
      quality: config.screenshots.quality,
      fullPage: true,
    });

    logger.info(`Screenshot taken: ${screenshotPath}`);
    return screenshotPath;
  }
}

export const browserManager = BrowserManager.getInstance();