import { Reporter, TestCase, TestResult, FullResult } from '@playwright/test/reporter';
import { logger } from './logger';
import fs from 'fs';
import path from 'path';

/**
 * Custom test reporter for enhanced reporting capabilities
 */
class CustomReporter implements Reporter {
  private startTime: number = 0;
  private results: Array<{ test: TestCase; result: TestResult }> = [];

  onBegin(config: any, suite: any) {
    this.startTime = Date.now();
    logger.info('Test execution started', {
      totalTests: suite.allTests().length,
      projects: config.projects.map((p: any) => p.name),
    });
  }

  onTestBegin(test: TestCase) {
    logger.step(test.title, 'Test started');
  }

  onTestEnd(test: TestCase, result: TestResult) {
    const duration = result.duration;
    const passed = result.status === 'passed';
    
    this.results.push({ test, result });
    
    logger.testResult(test.title, passed, duration);
    
    if (!passed) {
      logger.error(`Test failed: ${test.title}`, {
        error: result.error?.message,
        stack: result.error?.stack,
        attachments: result.attachments.map(a => a.path),
      });
    }
  }

  onEnd(result: FullResult) {
    const duration = Date.now() - this.startTime;
    const passed = this.results.filter(r => r.result.status === 'passed').length;
    const failed = this.results.filter(r => r.result.status === 'failed').length;
    const skipped = this.results.filter(r => r.result.status === 'skipped').length;

    const summary = {
      total: this.results.length,
      passed,
      failed,
      skipped,
      duration,
      status: result.status,
    };

    logger.info('Test execution completed', summary);

    // Generate custom JSON report
    this.generateCustomReport(summary);
  }

  private generateCustomReport(summary: any) {
    const reportPath = path.join('./src/reports', 'custom-report.json');
    
    const report = {
      summary,
      tests: this.results.map(({ test, result }) => ({
        title: test.title,
        file: test.location.file,
        line: test.location.line,
        status: result.status,
        duration: result.duration,
        error: result.error?.message,
        attachments: result.attachments.map(a => ({
          name: a.name,
          path: a.path,
          contentType: a.contentType,
        })),
      })),
      timestamp: new Date().toISOString(),
    };

    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
    logger.info(`Custom report generated: ${reportPath}`);
  }
}

export default CustomReporter;