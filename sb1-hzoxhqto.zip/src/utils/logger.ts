import winston from 'winston';
import { config } from '../config/test.config';
import { LogLevel, LogEntry } from '../types';

/**
 * Centralized logging system for the test framework
 */
class Logger {
  private static instance: Logger;
  private winston: winston.Logger;

  private constructor() {
    this.winston = winston.createLogger({
      level: config.logging.level,
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.errors({ stack: true }),
        winston.format.json(),
        winston.format.prettyPrint()
      ),
      transports: this.getTransports(),
    });
  }

  /**
   * Get singleton instance of Logger
   */
  public static getInstance(): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger();
    }
    return Logger.instance;
  }

  private getTransports(): winston.transport[] {
    const transports: winston.transport[] = [];

    if (config.logging.enableConsole) {
      transports.push(
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          ),
        })
      );
    }

    if (config.logging.enableFile) {
      transports.push(
        new winston.transports.File({
          filename: `${config.reports.outputDir}/test.log`,
          format: winston.format.json(),
        })
      );
    }

    return transports;
  }

  /**
   * Log an error message
   */
  public error(message: string, metadata?: Record<string, any>): void {
    this.winston.error(message, metadata);
  }

  /**
   * Log a warning message
   */
  public warn(message: string, metadata?: Record<string, any>): void {
    this.winston.warn(message, metadata);
  }

  /**
   * Log an info message
   */
  public info(message: string, metadata?: Record<string, any>): void {
    this.winston.info(message, metadata);
  }

  /**
   * Log a debug message
   */
  public debug(message: string, metadata?: Record<string, any>): void {
    this.winston.debug(message, metadata);
  }

  /**
   * Log test step
   */
  public step(testName: string, stepDescription: string): void {
    this.info(`[${testName}] ${stepDescription}`);
  }

  /**
   * Log test result
   */
  public testResult(testName: string, passed: boolean, duration: number): void {
    const status = passed ? 'PASSED' : 'FAILED';
    this.info(`[${testName}] ${status} - Duration: ${duration}ms`);
  }

  /**
   * Log API request/response
   */
  public api(method: string, url: string, status: number, duration: number): void {
    this.info(`API: ${method} ${url} - ${status} (${duration}ms)`);
  }

  /**
   * Create a child logger with additional context
   */
  public child(metadata: Record<string, any>): winston.Logger {
    return this.winston.child(metadata);
  }
}

export const logger = Logger.getInstance();