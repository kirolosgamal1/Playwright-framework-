import fs from 'fs';
import path from 'path';
import { NaturalLanguageTestSuite, NaturalLanguageTest } from '../mcp/natural-language-test';
import { logger } from './logger';

/**
 * Utility for generating and managing MCP-based tests
 */
export class MCPTestGenerator {
  private testDataDir: string;
  private generatedTestsDir: string;

  constructor() {
    this.testDataDir = './src/test-data/natural-language-tests';
    this.generatedTestsDir = './src/tests/generated';
    
    // Ensure directories exist
    this.ensureDirectoryExists(this.testDataDir);
    this.ensureDirectoryExists(this.generatedTestsDir);
  }

  /**
   * Generate Playwright test files from all JSON test definitions
   */
  public generateAllTests(): void {
    const jsonFiles = this.getJsonTestFiles();
    
    jsonFiles.forEach(filePath => {
      try {
        const testSuite = this.loadTestSuite(filePath);
        const outputPath = this.getGeneratedTestPath(filePath);
        
        NaturalLanguageTest.generatePlaywrightTest(testSuite, outputPath);
        logger.info(`Generated test: ${outputPath}`);
      } catch (error) {
        logger.error(`Failed to generate test from ${filePath}`, { error });
      }
    });
  }

  /**
   * Create a new natural language test template
   */
  public createTestTemplate(
    name: string,
    description: string,
    tags: string[] = []
  ): string {
    const template: NaturalLanguageTestSuite = {
      name,
      description,
      tags: ['mcp', ...tags],
      metadata: {
        author: 'Test Automation Team',
        created: new Date().toISOString().split('T')[0],
        version: '1.0',
        environment: 'all',
      },
      setup: [
        {
          command: 'navigate to "/"',
          description: 'Navigate to target page',
        },
        {
          command: 'wait for page to load completely',
          description: 'Ensure page is ready',
        },
      ],
      steps: [
        {
          command: 'take screenshot of current page',
          description: 'Capture initial state',
          screenshot: true,
        },
        {
          command: 'verify page title contains "Expected Title"',
          description: 'Validate page loaded correctly',
        },
      ],
      cleanup: [
        {
          command: 'take screenshot of current page',
          description: 'Capture final state',
        },
      ],
    };

    const fileName = this.sanitizeFileName(name) + '.json';
    const filePath = path.join(this.testDataDir, fileName);
    
    fs.writeFileSync(filePath, JSON.stringify(template, null, 2));
    logger.info(`Created test template: ${filePath}`);
    
    return filePath;
  }

  /**
   * Validate all JSON test files
   */
  public validateAllTests(): ValidationResult[] {
    const jsonFiles = this.getJsonTestFiles();
    const results: ValidationResult[] = [];

    jsonFiles.forEach(filePath => {
      try {
        const testSuite = this.loadTestSuite(filePath);
        const validation = this.validateTestSuite(testSuite);
        
        results.push({
          filePath,
          isValid: validation.isValid,
          errors: validation.errors,
          warnings: validation.warnings,
        });
      } catch (error) {
        results.push({
          filePath,
          isValid: false,
          errors: [`Failed to load test suite: ${error}`],
          warnings: [],
        });
      }
    });

    return results;
  }

  /**
   * Get command usage statistics
   */
  public getCommandStatistics(): CommandStatistics {
    const jsonFiles = this.getJsonTestFiles();
    const stats: CommandStatistics = {
      totalTests: 0,
      totalCommands: 0,
      commandTypes: {},
      mostUsedCommands: [],
    };

    jsonFiles.forEach(filePath => {
      try {
        const testSuite = this.loadTestSuite(filePath);
        stats.totalTests++;
        
        const allCommands = [
          ...(testSuite.setup || []),
          ...testSuite.steps,
          ...(testSuite.cleanup || []),
        ];

        allCommands.forEach(step => {
          stats.totalCommands++;
          const commandType = this.getCommandType(step.command);
          stats.commandTypes[commandType] = (stats.commandTypes[commandType] || 0) + 1;
        });
      } catch (error) {
        logger.warn(`Failed to analyze ${filePath}`, { error });
      }
    });

    // Sort most used commands
    stats.mostUsedCommands = Object.entries(stats.commandTypes)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 10)
      .map(([command, count]) => ({ command, count }));

    return stats;
  }

  private getJsonTestFiles(): string[] {
    if (!fs.existsSync(this.testDataDir)) {
      return [];
    }

    return fs.readdirSync(this.testDataDir)
      .filter(file => file.endsWith('.json'))
      .map(file => path.join(this.testDataDir, file));
  }

  private loadTestSuite(filePath: string): NaturalLanguageTestSuite {
    const content = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(content);
  }

  private getGeneratedTestPath(jsonFilePath: string): string {
    const baseName = path.basename(jsonFilePath, '.json');
    return path.join(this.generatedTestsDir, `${baseName}.spec.ts`);
  }

  private validateTestSuite(testSuite: NaturalLanguageTestSuite): {
    isValid: boolean;
    errors: string[];
    warnings: string[];
  } {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Required fields validation
    if (!testSuite.name) errors.push('Test suite name is required');
    if (!testSuite.steps || testSuite.steps.length === 0) {
      errors.push('Test suite must have at least one step');
    }

    // Command validation
    const allCommands = [
      ...(testSuite.setup || []),
      ...testSuite.steps,
      ...(testSuite.cleanup || []),
    ];

    allCommands.forEach((step, index) => {
      if (!step.command) {
        errors.push(`Step ${index + 1} is missing command`);
      }
    });

    // Warnings for best practices
    if (!testSuite.description) {
      warnings.push('Test suite description is recommended');
    }
    if (!testSuite.tags || testSuite.tags.length === 0) {
      warnings.push('Test suite tags are recommended for organization');
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
    };
  }

  private getCommandType(command: string): string {
    const lowerCommand = command.toLowerCase();
    
    if (lowerCommand.includes('navigate') || lowerCommand.includes('go to')) return 'navigation';
    if (lowerCommand.includes('click') || lowerCommand.includes('tap')) return 'click';
    if (lowerCommand.includes('type') || lowerCommand.includes('enter') || lowerCommand.includes('fill')) return 'input';
    if (lowerCommand.includes('verify') || lowerCommand.includes('check') || lowerCommand.includes('assert')) return 'assertion';
    if (lowerCommand.includes('wait') || lowerCommand.includes('pause')) return 'wait';
    if (lowerCommand.includes('screenshot') || lowerCommand.includes('capture')) return 'screenshot';
    if (lowerCommand.includes('scroll')) return 'scroll';
    if (lowerCommand.includes('hover')) return 'hover';
    
    return 'other';
  }

  private sanitizeFileName(name: string): string {
    return name
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim();
  }

  private ensureDirectoryExists(dirPath: string): void {
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
  }
}

interface ValidationResult {
  filePath: string;
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

interface CommandStatistics {
  totalTests: number;
  totalCommands: number;
  commandTypes: Record<string, number>;
  mostUsedCommands: Array<{ command: string; count: number }>;
}

export const mcpTestGenerator = new MCPTestGenerator();