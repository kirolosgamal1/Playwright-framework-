import { User, TestData } from '../types';

/**
 * Test data factory for generating test data
 */
class TestDataFactory {
  private static instance: TestDataFactory;

  private constructor() {}

  public static getInstance(): TestDataFactory {
    if (!TestDataFactory.instance) {
      TestDataFactory.instance = new TestDataFactory();
    }
    return TestDataFactory.instance;
  }

  /**
   * Generate a valid user
   */
  public createValidUser(overrides?: Partial<User>): User {
    const timestamp = Date.now();
    return {
      email: `user_${timestamp}@example.com`,
      password: 'ValidPassword123!',
      firstName: 'Test',
      lastName: 'User',
      role: 'user',
      ...overrides,
    };
  }

  /**
   * Generate an admin user
   */
  public createAdminUser(overrides?: Partial<User>): User {
    return this.createValidUser({
      role: 'admin',
      email: `admin_${Date.now()}@example.com`,
      ...overrides,
    });
  }

  /**
   * Generate an invalid user (for negative testing)
   */
  public createInvalidUser(): User {
    return {
      email: 'invalid-email',
      password: '123',
      firstName: '',
      lastName: '',
      role: 'user',
    };
  }

  /**
   * Generate test data set
   */
  public getTestData(): TestData {
    return {
      users: {
        valid: this.createValidUser(),
        invalid: this.createInvalidUser(),
        admin: this.createAdminUser(),
      },
      urls: {
        home: '/',
        login: '/login',
        dashboard: '/dashboard',
        profile: '/profile',
      },
    };
  }

  /**
   * Generate random string
   */
  public randomString(length: number = 8): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  /**
   * Generate random email
   */
  public randomEmail(): string {
    return `${this.randomString()}@example.com`;
  }

  /**
   * Generate random number
   */
  public randomNumber(min: number = 1, max: number = 100): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
}

export const testDataFactory = TestDataFactory.getInstance();