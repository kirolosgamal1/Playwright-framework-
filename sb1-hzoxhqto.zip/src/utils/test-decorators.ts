import { test } from '@playwright/test';
import { logger } from './logger';
import { config } from '../config/test.config';

/**
 * Test decorators for enhanced test functionality
 */

/**
 * Retry decorator for flaky tests
 */
export function retry(count: number = config.retries.count, delay: number = config.retries.delay) {
  return function (target: any, propertyName: string, descriptor: PropertyDescriptor) {
    const method = descriptor.value;
    descriptor.value = async function (...args: any[]) {
      let lastError: Error | undefined;
      
      for (let i = 0; i <= count; i++) {
        try {
          return await method.apply(this, args);
        } catch (error) {
          lastError = error as Error;
          logger.warn(`Test attempt ${i + 1} failed: ${lastError.message}`);
          
          if (i < count) {
            await new Promise(resolve => setTimeout(resolve, delay));
          }
        }
      }
      
      throw lastError;
    };
  };
}

/**
 * Performance monitoring decorator
 */
export function performance(threshold: number = 3000) {
  return function (target: any, propertyName: string, descriptor: PropertyDescriptor) {
    const method = descriptor.value;
    descriptor.value = async function (...args: any[]) {
      const startTime = Date.now();
      
      try {
        const result = await method.apply(this, args);
        const duration = Date.now() - startTime;
        
        logger.info(`Performance: ${propertyName} completed in ${duration}ms`);
        
        if (duration > threshold) {
          logger.warn(`Performance warning: ${propertyName} exceeded threshold (${duration}ms > ${threshold}ms)`);
        }
        
        return result;
      } catch (error) {
        const duration = Date.now() - startTime;
        logger.error(`Performance: ${propertyName} failed after ${duration}ms`, { error });
        throw error;
      }
    };
  };
}

/**
 * Screenshot decorator for visual debugging
 */
export function screenshot(name?: string) {
  return function (target: any, propertyName: string, descriptor: PropertyDescriptor) {
    const method = descriptor.value;
    descriptor.value = async function (...args: any[]) {
      try {
        const result = await method.apply(this, args);
        
        if (this.page) {
          const screenshotName = name || `${propertyName}_${Date.now()}`;
          await this.page.screenshot({
            path: `./src/reports/screenshots/${screenshotName}.png`,
            fullPage: true,
          });
          logger.info(`Screenshot captured: ${screenshotName}.png`);
        }
        
        return result;
      } catch (error) {
        if (this.page) {
          const screenshotName = `${name || propertyName}_error_${Date.now()}`;
          await this.page.screenshot({
            path: `./src/reports/screenshots/${screenshotName}.png`,
            fullPage: true,
          });
          logger.error(`Error screenshot captured: ${screenshotName}.png`);
        }
        throw error;
      }
    };
  };
}

/**
 * Custom test tags for categorization
 */
export const testTags = {
  api: test.extend({
    // API test specific setup
  }),
  
  visual: test.extend({
    // Visual test specific setup
  }),
  
  performance: test.extend({
    // Performance test specific setup
  }),
  
  smoke: test.extend({
    // Smoke test specific setup
  }),
  
  regression: test.extend({
    // Regression test specific setup
  }),
};